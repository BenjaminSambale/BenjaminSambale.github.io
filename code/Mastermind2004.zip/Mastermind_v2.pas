PROGRAM Mastermind;
USES CRT;
TYPE combi=ARRAY [0..8] OF INTEGER;
VAR xt,x1 : COMBI;
    Digits,zi,za,wa,i,verr : INTEGER;
    z,z2,Punkte : LONGINT;
    richtig : STRING;
    f,g : TEXT;
    Quit,cheats : BOOLEAN;
    HighscoreName : Array[0..9] OF STRING;
    HighscorePoints : Array[0..9] OF LONGINT;

PROCEDURE split(i:INTEGER;z:LONGINT); {Longintzahl in einzelne Ziffern zerlegen}
BEGIN                                            {und im Array xt speichern}
  xt[Digits-i]:=z MOD 10;
  z:=z DIV 10;
  IF i<=Digits THEN split(i+1,z);
END;

PROCEDURE split2(i:INTEGER;z:LONGINT;zi:INTEGER);  {wie split nur mit variabler Basis und ohne Nullen}
BEGIN                                              {wird von der Prozedur "erzeugen" verwendet}
  xt[Digits-i]:=(z MOD zi)+1;
  z:=z DIV zi;
  IF i<=Digits THEN split2(i+1,z,zi);
END;

FUNCTION pot(b:INTEGER;e:INTEGER):LONGINT;   {potenzieren mit Ganzenzahlen b hoch e}
VAR i : INTEGER;
    p : LONGINT;
BEGIN
  IF e=0 THEN pot:=1 ELSE
  BEGIN
    p:=1;
    FOR i:=1 TO e DO p:=p*b;
    pot:=p;
  END;
END;

PROCEDURE erzeuge(Digits:INTEGER;zi:INTEGER);  {erzeugt Liste in Datei mit allen m�glichen Kombos}
VAR j:INTEGER;
    k:LONGINT;
BEGIN
  assign(f,'liste.txt');
  rewrite(f);
  FOR k:=0 TO pot(zi,Digits)-1 DO
  BEGIN
    split2(1,k,zi);
    FOR j:=0 TO Digits-1 DO write(f,xt[j]);
    write(f,' ');
  END;
  close(f);
END;

FUNCTION test(xin,xin2:combi):STRING;   {gibt den Antwortstring aus einen Vergleich aus}
VAR str:STRING;
    i,j:INTEGER;
BEGIN
  str:='';
  FOR i:=0 TO Digits-1 DO
  IF xin2[i]=xin[i] THEN BEGIN str:=str+'+'; xin[i]:=-2; xin2[i]:=-1; END;
  FOR i:=0 TO Digits-1 DO
    FOR j:=0 TO Digits-2 DO
      IF xin2[i]=xin[(j+i+1) MOD Digits] THEN
      BEGIN
        str:=str+'-'; xin[(j+i+1) MOD Digits]:=-2;
        xin2[i]:=-1;
      END;
  test:=str;
END;

PROCEDURE DrawFrame(OL_X,OL_Y,UR_X,UR_Y : INTEGER; DBLFRAME:BOOLEAN);
VAR zeichen : CHAR;
    X,Y,i : INTEGER;
BEGIN
  {Zeichne Ecken}
  IF DBLFRAME=FALSE THEN zeichen:='�' ELSE zeichen:='�';
  gotoXY(OL_X,OL_Y); write(zeichen);
  IF DBLFRAME=FALSE THEN zeichen:='�' ELSE zeichen:='�';
  gotoXY(UR_X,OL_Y); write(zeichen);
  IF DBLFRAME=FALSE THEN zeichen:='�' ELSE zeichen:='�';
  gotoXY(OL_X,UR_Y); write(zeichen);
  IF DBLFRAME=FALSE THEN zeichen:='�' ELSE zeichen:='�';
  gotoXY(UR_X,UR_Y); write(zeichen);
  {Zeichne Horizontalen}
  IF DBLFRAME=FALSE THEN zeichen:='�' ELSE zeichen:='�';
  X:=OL_X;
  FOR i:=0 TO UR_X-OL_X-2 DO
    BEGIN
    gotoXY(X+1,OL_Y);
    write(zeichen);
    gotoXY(X+1,UR_Y);
    write(zeichen);
    X:=X+1;
    END;
  {Zeichne Vertikalen}
  IF DBLFRAME=FALSE THEN zeichen:='�' ELSE zeichen:='�';
  Y:=OL_Y;
  FOR i:=0 TO UR_Y-OL_Y-2 DO
    BEGIN
    gotoXY(OL_X,Y+1);
    write(zeichen);
    gotoXY(UR_X,Y+1);
    write(zeichen);
    Y:=Y+1;
    END;
END;

PROCEDURE DrawHighscore;
BEGIN
  clrscr;
  DrawFrame(21,1,59,3,false);   {Mastermind-Umrandung}
  DrawFrame(15,5,65,20,false);
  DrawFrame(10,2,70,24,false);   {Hauptumrandung}
  gotoXY(21,2); write('�');
  gotoXY(59,2); write('�');
  gotoXY(22,2); write(' * * *  MASTERMIND-HIGHSCORES  * * * ');
END;

function FileExists(FileName: String): Boolean;
var
 F: file;
begin
 {$I-}
 Assign(F, FileName);
 Reset(F);
 Close(F);
 {$I+}
 FileExists := (IOResult = 0) and (FileName <> '');
end;

PROCEDURE GetHighscore;
VAR i : INTEGER;
BEGIN;
  {Arrays initialisieren}
  FOR i:=0 TO 9 DO
    BEGIN
    HighscoreName[i]:=' ';
    HighscorePoints[i]:=-1;
    END;
  {Datei �ffnen}
  assign(g,'highsc.001'); { Weist der Variable g : TEXT den Inhalt von highsc.001 zu }
  IF fileexists('highsc.001')=false THEN
     rewrite(g)
  ELSE
    BEGIN
    reset(g);
    i:=0;
    WHILE NOT EOF(g) DO
      BEGIN
      readln(g,HighscoreName[i]);
      readln(g,HighscorePoints[i]);
      INC(i);
      END;
    END;
  close(g);
END;

PROCEDURE SetHighScore(Name : STRING; Punkte2 : LONGINT);
VAR  i : INTEGER;
    ch : CHAR;
BEGIN
  {Punkte und Namen aus highsc.001 in Arrays speichern}
  GetHighscore;
  {Ergebnis in die Liste einordnen}
  assign(g,'highsc.001'); { Weist der Variable g : TEXT den Inhalt von highsc.001 zu }
  reset(g);
  i:=9;
  WHILE (Punkte2>=HighscorePoints[i]) AND (i>-1) DO
    BEGIN
    IF (Punkte2>HighscorePoints[i-1]) AND (i>0) THEN
      BEGIN
      HighscorePoints[i]:=HighscorePoints[i-1];
      HighscoreName[i]:=HighscoreName[i-1];
      END
    ELSE
      BEGIN
      HighscorePoints[i]:=Punkte2;
      HighscoreName[i]:=Name;
      i:=0;
      END;
    DEC(i);
    END;
  {highsc.001 aktualisieren}
  rewrite(g);
  FOR i:=0 TO  9 DO
    IF HighscorePoints[i]<>-1 THEN
      BEGIN
      write(g,HighscoreName[i],CHR(13));
      write(g,HighscorePoints[i],CHR(13));
      END;
  close(g);
END;

PROCEDURE ShowHighScore;
VAR ch : CHAR;
     i : INTEGER;
BEGIN
  DrawHighscore;
  GetHighscore;
  i:=0;
  WHILE (i<10) AND (Highscorepoints[i]<>-1) DO
    BEGIN
    gotoXY(27,i+7);
    IF i=0 THEN
      TextColor(LightRed)
    ELSE
      TextColor(15);
    write(i+1,'.');
    gotoXY(30,i+7);
    write(HighscorePoints[i]);
    gotoXY(38,i+7);
    write('-');
    gotoXY(41,i+7);
    write(HighscoreName[i]);
    INC(i);
    END;
    TextColor(White);
  gotoXY(25,22);
  write('Taste dr�cken, "L" zum l�schen');
  ch:=readkey;
  IF (ch='l') OR (ch='L') THEN rewrite(g);
END;

PROCEDURE WriteColor (number : LONGINT);
VAR multi,number2 : LONGINT;
    single : INTEGER;
BEGIN
  CASE number OF
    1: TextColor(4);  {Red}
    2: TextColor(9);  {LightBlue}
    3: TextColor(14); {Yellow}
    4: TextColor(2);  {Green}
    5: TextColor(13); {LightPink}
    6: TextColor(15); {White}
    7: TextColor(6);  {Brown}
    8: TextColor(3);  {Cyan}
    9: TextColor(12); {LightRed}
    ELSE
      IF number>0 THEN
      BEGIN
        number2:=number;
        multi:=100000000;
        REPEAT
        single:=(number2-(number2 MOD multi)) DIV multi;
        number2:=number2-(single*multi);
        multi:=multi DIV 10;
        WriteColor(Single);
        UNTIL multi<1;
      END;
   END;
   IF (number<10) AND (number>0) THEN
   BEGIN
   write('* ');
   TextColor(White);
   END;
END;

PROCEDURE verrate(i:INTEGER);
VAR j:INTEGER;
BEGIN
  gotoXY(51,25);
  FOR j:=0 TO i DO
  BEGIN
    writecolor(x1[j]);
    write(' ');
  END;
  TextColor(8);
  FOR j:=2 TO Digits-i DO write('*  ');
  TextColor(White);
END;

PROCEDURE ShowChoiceboard(Digits,Ziffern,X_POS,Y_POS : INTEGER);
VAR i,j : INTEGER;
BEGIN
  gotoXY(X_POS+3,Y_POS-1);
  FOR i:=0 TO Ziffern DO
    BEGIN
    FOR j:=0 TO Digits-1 DO
      BEGIN
      WriteColor(i);
      IF i>0 THEN write(' ');
      END;
    gotoXY(X_POS+2,Y_POS-1+2*(i+1));
    END;
END;

PROCEDURE HideCertainChoices(Digits,Ziffern,X_POS,Y_POS,Choice : INTEGER);
VAR i : INTEGER;
BEGIN
  TextColor(8);
  X_POS:=X_POS+2;
  Y_POS:=Y_POS+1;
  FOR i:=0 TO Ziffern-1 DO
  BEGIN
    gotoXY(X_POS,Y_POS+i*2);
    write('*');
  END;
  gotoXY(X_POS,Y_POS+2*(Choice-1));
  WriteColor(Choice);
  TextColor(7);
  gotoXY(1,25);
END;

PROCEDURE Selector(X_POS,Y_POS : INTEGER; SHOW : BOOLEAN);
BEGIN
  IF SHOW = true THEN TextColor(23) ELSE TextColor(0);
  gotoXY(X_POS,Y_POS); write('�');
  gotoXY(X_POS+4,Y_POS); write('�');
  gotoXY(X_POS,Y_POS+2); write('�');
  gotoXY(X_POS+4,Y_POS+2); write('�');
END;

FUNCTION SelectChoice(Digits,Ziffern,X_POS,Y_POS : INTEGER) : LONGINT;
VAR merke_X,merke_Y: INTEGER;
    choice : CHAR;
    oben, unten : BOOLEAN;
BEGIN
    merke_X:=X_POS;
    merke_Y:=Y_POS;
    X_POS:=X_POS-1;
    Y_POS:=Y_POS-1;
    Selector(merke_X,merke_Y,true);
    gotoXY(1,25);
    unten:=true;
    oben:=false;
    REPEAT
      choice:=readkey;
      IF ((choice='s') OR (choice='S')) AND (cheats=TRUE) AND (verr<Digits) THEN
      BEGIN
        verrate(verr);
        INC(verr);
      END;
      IF choice=CHR(0) THEN
      BEGIN
        choice:=readkey;
        IF (choice=CHR(80)) AND (unten=true) THEN
          BEGIN
          Selector(merke_X,merke_Y,false);
          merke_Y:=merke_Y+2;
          Selector(merke_X,merke_Y,true);
          oben:=true;
          unten:=false;
          IF ((merke_Y<=Ziffern*2) OR (merke_Y<=Ziffern*2)) AND (Ziffern<>2) THEN
            unten:=true;
          END;
        IF (choice=CHR(72)) AND (oben=true) THEN
          BEGIN
          Selector(merke_X,merke_Y,false);
          merke_Y:=merke_Y-2;
          Selector(merke_X,merke_Y,true);
          unten:=true;
          oben:=false;
          IF (merke_Y<>Y_POS+1) AND (Ziffern<>2) THEN
            oben:=true;
          END;
          gotoXY(1,25);
        END;
    UNTIL choice=CHR(13);
    Selector(merke_X,merke_Y,false);
    TextColor(White);
    SelectChoice:=(merke_Y+1-Y_POS) DIV 2;
END;

FUNCTION Choiceboard(Digits,Ziffern,X_POS,Y_POS : INTEGER) : LONGINT;
VAR i,choice : INTEGER;
    number : LONGINT;
BEGIN
    number:=0;
    IF (Ziffern>1) AND (Ziffern<10) THEN
      BEGIN
      ShowChoiceboard(Digits,Ziffern,X_POS,Y_POS);
      verr:=0;
      FOR i:=Digits DOWNTO 1 DO
      BEGIN
        choice:=SelectChoice(Digits,Ziffern,X_POS+(Digits-i)*3,Y_POS);
        number:=number+choice*pot(10,i-1);
        HideCertainChoices(Digits,Ziffern,X_POS+(Digits-i)*3,Y_POS,choice);
      END;
      END;
    Choiceboard:=number;
END;

FUNCTION MenuScreen : INTEGER;
VAR choice : INTEGER;
    ch : CHAR;
BEGIN
  clrscr;
  DrawFrame(10,5,70,24,false);
  DrawFrame(16,3,64,8,false);
  gotoXY(16,5); write('�');
  gotoXY(64,5); write('�');
  TextColor(LightBlue);
  gotoXY(17,4); write(' _  _ ____ ____ ___ ____ ____ _  _ _ _  _ ___  ');
  gotoXY(17,5); write(' |\/| |__| [__   |  |___ |__/ |\/| | |\ | |  \ ');
  gotoXY(17,6); write(' |  | |  | ___]  |  |___ |  \ |  | | | \| |__/ ');
  TextColor(15);
  DrawFrame(29,10,51,22,false);
  gotoXY(31,11); write('(1) Du r�tst');
  gotoXY(31,12); write('(2) Computer r�t');
  gotoXY(31,13); write('(3) Computer gegen');
  gotoXY(31,14); write('    sich selbst');
  gotoXY(31,15); write('-------------------');
  gotoXY(31,16); write('(4) Spielregeln');
  gotoXY(31,17); write('(5) Spielanleitung');
  gotoXY(31,18); write('-------------------');
  gotoXY(31,19); write('(6) Highscores');
  gotoXY(31,20); write('(7) Credits');
  gotoXY(31,21); write('(8) Ende');
  gotoXY(1,25);
  IF cheats=TRUE THEN
  BEGIN
    gotoxy(53,7);
    TextColor(140);
    write('Cheats on!');
    TextColor(White);
    gotoXY(1,25);
  END;
  REPEAT
    ch:=readkey;
    IF ch='e' THEN
      IF readkey='i' THEN
        IF readkey='n' THEN
          IF readkey='s' THEN
            IF readkey='t' THEN
              IF readkey='e' THEN
                IF readkey='i' THEN
                  IF readkey='n' THEN
                  BEGIN
                    cheats:=TRUE;
                    gotoXY(53,7);
                    TextColor(140);
                    write('Cheats on!');
                    TextColor(White);
                    gotoXY(1,25);
                  END;
    IF (ORD(ch)<49) OR (ORD(ch)>56) THEN
    choice:=0
    ELSE choice:=ORD(ch)-48;
  UNTIL choice>0;
  MenuScreen:=choice;
END;

PROCEDURE DrawGameScreen(Modus : BOOLEAN);
BEGIN
  clrscr;
  DrawFrame(21,1,59,3,false);   {Mastermind-Umrandung}
  DrawFrame(48,2,79,24,false);  {rechte Umrandung}
  DrawFrame(2,2,26,24,false);   {linke Umrandung}
  DrawFrame(2,2,79,24,false);   {Hauptumrandung}
  gotoXY(21,2); write('�');
  gotoXY(59,2); write('�');
  gotoXY(26,3); write('�');
  gotoXY(48,3); write('�');
  gotoXY(26,24); write('�');
  gotoXY(48,24); write('�');
  gotoXY(22,2);
  TextColor(LightBlue);
  IF Modus=TRUE THEN
    write('  * * * * *  MASTERMIND  * * * * *   ')
  ELSE
    write(' * * *  MASTERMIND - COMPUTER  * * * ');
  TextColor(15);
END;

PROCEDURE ShowText(text : INTEGER);
{PROCEDURE f�r die Darstellung eines vordefinierten Textes in der Bildschirmmitte}
BEGIN
  gotoXY(28,5);
  CASE text OF
  1: {Textmeldung f�r Sieg des Spielers}
     BEGIN write('Du hast gewonnen!'); gotoXY(28,7); write('Punktezahl: ',Punkte); gotoXY(28,9); write('Name eingeben:');
     gotoXY(28,10); Textbackground(9); write('                   '); gotoXY(28,10); END;
  2: {Textmeldung f�r Niederlage des Spielers}
     BEGIN write('Du hast die Kombi-'); gotoXY(28,6); write('nation nicht er-'); gotoXY(28,7); write('raten!');
     gotoXY(28,9); write('Der Computer hat'); gotoXY(28,10); write('gewonnen!'); gotoXY(1,25);END;
  3: {Textmeldung f�r Sieg des Computers}
     BEGIN write('Der Computer hat'); gotoXY(28,6); write('deine Kombination'); gotoXY(28,7); write('erraten!');
     gotoXY(1,25); END;
  4: {Textmeldung f�r falsche Hinweise des Spielers}
     BEGIN write('Das kann nicht'); gotoXY(28,6); write('sein, mindestens'); gotoXY(28,7); write('eine Antwort war');
     gotoXY(28,8); write('falsch!'); gotoXY(28,10); write('Der Computer'); gotoXY(28,11); write('hat gewonnen!');
     gotoXY(1,25); END;
  5: {Textmeldung f�r Computer gibt auf}
     BEGIN write('Der Computer'); gotoXY(28,6); write('gibt auf !'); gotoXY(1,25); END;
  6: {Textmeldung f�r Computer gewinnt gegen sich selbst}
     BEGIN write('Der Computer hat'); gotoXY(28,6); write('seine Kombination'); gotoXY(28,7); write('erraten!');
     gotoXY(1,25); END;
  END;
END;

PROCEDURE HideText;
VAR i : INTEGER;
BEGIN
  FOR i:=0 TO 19 DO
  BEGIN
    gotoXY(27,i+4);
    write('                     ');
  END;
END;

FUNCTION init(Modus : BOOLEAN) : BOOLEAN; {wenn init:=TRUE dann hat der Benutzer mit 'q' abgebrochen}
VAR choice : CHAR;
    return,quit : BOOLEAN;
    i : INTEGER;
BEGIN
    IF Modus=False THEN
      {Warnung}
      BEGIN
      TextColor(12);
      gotoXY(28,18);
      write('Vorsicht:');
      gotoXY(28,19);
      write('Die Berechnung kann');
      gotoXY(28,20);
      write('bei hohen Werten ab');
      gotoXY(28,21);
      write('7 etwas Zeit in An-');
      gotoXY(28,22);
      write('spruch nehmen!');
      TextColor(15);
      END;
    {Initialisiere Digits}
    gotoXY(28,5);
    write('Wieviele Stellen?');
    gotoXY(28,6);
    write('(min. 2, max. 9)');
    gotoXY(46,5);
    REPEAT
      choice:=ReadKey;
      IF ((ORD(choice)>49) AND (ORD(choice)<58)) THEN
      Digits:=ORD(choice)-48;
    UNTIL ((ORD(choice)>49) AND (ORD(choice)<58)) OR (ORD(choice)=81) OR (ORD(choice)=113);
    {Initialisiere zi}
    IF (ORD(choice)>49) AND (ORD(choice)<58) THEN
      BEGIN
      gotoXY(28,8);
      write('Wieviele Farben?');
      gotoXY(28,9);
      write('(min. 2, max. 9)');
      gotoXY(45,8);
      REPEAT
        choice:=ReadKey;
        IF ((ORD(choice)>49) AND (ORD(choice)<58)) THEN
          zi:=ORD(choice)-48;
      UNTIL ((ORD(choice)>49) AND (ORD(choice)<58)) OR (ORD(choice)=81) OR (ORD(choice)=113);
      {Wahl festhalten}
      gotoXY(27,11); write('---------------------');
      gotoXY(28,13);
      IF Modus=True THEN
        BEGIN write('Du spielst mit'); gotoXY(28,14); write(Digits,' Stellen und ',zi); gotoXY(28,15); write('Farben!'); END
      ELSE
        BEGIN write('Der Computer spielt'); gotoXY(28,14); write('mit ',Digits,' Stellen und ',zi); gotoXY(28,15);
        write('Farben!'); END;
      gotoXY(1,25);
      readkey;
      HideText;
      return:=FALSE;
      END
    ELSE return:=TRUE;
  {Initialisiere richtig}
  richtig:='';
  FOR i:=1 TO Digits DO richtig:=richtig+'+';
  init:=return;
END;

PROCEDURE winsound;
BEGIN
  sound(440);
  delay(100);
  nosound;
  sound(554);
  delay(200);
  nosound;
END;

PROCEDURE losesound;
BEGIN
  sound(220);
  delay(100);
  nosound;
  sound(185);
  delay(200);
  nosound;
END;

FUNCTION DuRaetst : BOOLEAN;
VAR i,j : INTEGER;
    number,zi2,Digits2,i2 : LONGINT;
    result : BOOLEAN;
    name : STRING [19];
    ch : ARRAY [0..18] OF CHAR;
    ch2 : CHAR;
BEGIN
  DrawGameScreen(True);
  result:=init(True);
  IF result=FALSE THEN
    BEGIN
    randomize;
    FOR i:=0 TO Digits-1 DO x1[i]:=random(zi)+1;
    i:=0;
    IF cheats=TRUE THEN
    BEGIN
      gotoXY(1,25);
      TextColor(LightBlue);
      write('s f�r dr�cken, um eine Stelle zu verraten');
      TextColor(White);
    END;
    REPEAT
      gotoXY(4,i*2+4);
      write('V',i+1,': ');
      number:=Choiceboard(Digits,zi,49,4);
      gotoXY(8,i*2+4);
      WriteColor(number);
      gotoXY(4,i*2+5);
      write('E',i+1,': ');
      gotoXY(8,i*2+5);
      split(1,number);
      write(test(x1,xt));
      INC(i);
    UNTIL (test(x1,xt)=richtig) OR (i=10);
    IF (test(x1,xt)=richtig) THEN
      BEGIN
      zi2:=zi;
      Digits2:=Digits;
      i2:=i;
      IF cheats=TRUE THEN Punkte:=sqr(zi2*Digits2)*(10-i2)*10 ELSE
      Punkte:=sqr(zi2*Digits2)*(10-i);
      ShowText(1);
      winsound;
      i:=0;
      REPEAT
        ch[i]:=readkey;
        IF (ch[i]<>CHR(8)) AND (ch[i]<>CHR(0)) AND (ch[i-1]<>CHR(0)) THEN write(ch[i]);
        IF (i>0) THEN IF (ch[i-1]=CHR(0)) THEN i:=i-2;
        IF (ch[i]=CHR(8)) AND (i=0) THEN DEC(i);
        IF ch[i]=CHR(13) THEN i:=i-2;
        IF (ch[i]=CHR(8)) AND (i>0) THEN
        BEGIN
          write(CHR(8),' ',CHR(8));
          i:=i-2;
        END;
        IF i=18 THEN
        REPEAT
        ch2:=readkey;
        IF ch2=CHR(8) THEN
        BEGIN
          write(CHR(8),' ',CHR(8));
          i:=i-1;
        END;
        UNTIL (ch2=CHR(13)) OR (ch2=CHR(8));
        INC(i);
      UNTIL (ch[i+1]=CHR(13)) OR (ch2=CHR(13));
      Name:='';
      FOR j:=0 TO i DO Name:=Name+ch[j];
      SetHighScore(Name,Punkte);
      TextBackground(0);
      ShowHighscore;
      END
    ELSE
    BEGIN
      ShowText(2);
      losesound;
      readln;
    END;
    END;
END;

PROCEDURE CRaet;
TYPE antwort=ARRAY [0..10] OF STRING;
VAR  x,x1,x2,x3,x4,x5,x6,x7,
     x8,x9,x10:combi;
     ant:antwort;
     i:INTEGER;
label zwei,drei,vier;
BEGIN
  DrawGameScreen(false);        {Zeichnet Spielbildschirm}
  init(false);                  {Initialisiert zi,Digits}
  gotoXY(28,20);
  write('W�hlen sie ihre');
  gotoXY(28,21);
  write('Geheimkombination!');
  Choiceboard(Digits,zi,49,4);  {Choiceboard wird zum Aussuchen einer Kombination genutzt}
  HideText;
  erzeuge(Digits,zi);           {Listendatei erzeugen}
  FOR i:=0 TO Digits-1 DO x1[i]:=(i MOD zi)+1;      {1. Versuch, z.B. 1234}
  reset(f);    {Listendatei �ffnen}
  TextColor(White);
  gotoXY(4,4); write('V1: ');
  FOR i:=0 TO Digits-1 DO WriteColor(x1[i]);
  gotoXY(4,5); write('E1: ');
  readln(ant[0]);
  IF ant[0]=richtig THEN
  BEGIN
    ShowText(3);
    exit;
  END;
  IF (zi>=3) AND (Digits=3) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    gotoXY(4,6); write('V2: '); WriteColor(122);
    GOTO zwei;
  END;
  IF (zi>=4) AND (Digits=4) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=2;
    gotoXY(4,6); write('V2: '); WriteColor(1222);
    GOTO zwei;
  END;
  IF (zi>=5) AND (Digits=5) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(12233);
    GOTO zwei;
  END;
  IF (zi>=6) AND (Digits=6) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(122333);
    GOTO zwei;
  END;
  IF (zi>=7) AND (Digits=7) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    x2[6]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(1223333);
    GOTO zwei;
  END;
  IF (zi>=8) AND (Digits=8) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    x2[6]:=3;
    x2[7]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(12233333);
    GOTO zwei;
  END;
  IF (zi=9) AND (Digits=9) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    x2[6]:=4;
    x2[7]:=4;
    x2[8]:=4;
    gotoXY(4,6); write('V2: '); WriteColor(122333444);
    GOTO zwei;
  END;
  IF (ant[0]='') AND (zi>Digits+1) THEN    {Verbesserung des Algo}
  BEGIN
    FOR i:=0 TO Digits-1 DO x2[i]:=(i MOD (zi-Digits))+Digits+1;
    gotoXY(4,6); write('V2: ');
    FOR i:=0 TO Digits-1 DO WriteColor(x2[i]);
    GOTO zwei;
  END;
  REPEAT
    read(f,z2);     {Zahl aus Listendatei lesen}
    split(1,z2);   {Zahl in einzelne Ziffern zerlegen}
  UNTIL (test(x1,xt)=ant[0]) OR (eof(f));
  IF (eof(f) AND (test(x1,xt)<>ant[0])) OR (z2=0) THEN     {2.Bedingung notwendig,da z.B. 4444 bei 4 Ziffern}
  BEGIN                                      {noch richtig sein kann, 3. Bedingung, weil er manchmal Null anbietet}
    Showtext(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x2[i]:=xt[i];  {gefunden Testzahl wird im neuen Array gespeichert,}
  gotoXY(4,6); write('V2: '); WriteColor(z2);            {da sie bei der n�chsten Suche �berschrieben wird}
  zwei:
  gotoXY(4,7); write('E2: ');
  readln(ant[1]);
  IF ant[1]=richtig THEN
  BEGIN
    Showtext(3);
    winsound;
    exit;
  END;
  IF (zi>=4) AND (Digits=4) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=3;
    x3[1]:=4;
    x3[2]:=4;
    x3[3]:=4;
    gotoXY(4,8); write('V3: '); WriteColor(3444);
    GOTO drei;
  END;
  IF (zi>=5) AND (Digits=5) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=4;
    x3[2]:=5;
    x3[3]:=5;
    x3[4]:=5;
    gotoXY(4,8); write('V3: '); WriteColor(44555);
    GOTO drei;
  END;
  IF (zi>=6) AND (Digits=6) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=5;
    x3[2]:=5;
    x3[3]:=6;
    x3[4]:=6;
    x3[5]:=6;
    gotoXY(4,8); write('V3: '); WriteColor(455666);
    GOTO drei;
  END;
  IF (zi>=7) AND (Digits=7) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=5;
    x3[2]:=5;
    x3[3]:=6;
    x3[4]:=6;
    x3[5]:=6;
    x3[6]:=6;
    gotoXY(4,8); write('V3: '); WriteColor(4556666);
    GOTO drei;
  END;
  IF (zi>=8) AND (Digits=8) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=5;
    x3[2]:=5;
    x3[3]:=6;
    x3[4]:=6;
    x3[5]:=6;
    x3[6]:=6;
    x3[7]:=6;
    gotoXY(4,8); write('V3: '); WriteColor(45566666);
    GOTO drei;
  END;
  IF (zi=9) AND (Digits=9) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=5;
    x3[1]:=6;
    x3[2]:=6;
    x3[3]:=7;
    x3[4]:=7;
    x3[5]:=7;
    x3[6]:=8;
    x3[7]:=8;
    x3[8]:=8;
    gotoXY(4,8); write('V3: '); WriteColor(566777888);
    GOTO drei;
  END;
  IF (ant[0]='') AND (ant[1]='') AND (zi>((2*Digits)+1)) THEN    {Verbesserung des Algo}
  BEGIN
    FOR i:=0 TO Digits-1 DO x3[i]:=(i MOD (zi-2*Digits))+2*Digits+1;
    gotoXY(4,8); write('V3: ');
    FOR i:=0 TO Digits-1 DO WriteColor(x3[i]);
    GOTO drei;
  END;
  REPEAT
    read(f,z2);    {an der letzten Stelle wird weitergelesen, nicht wieder von vorn}
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND    {alle vorhergehenden Versuch m�ssen}
  (test(x2,xt)=ant[1])) OR           {bei der Suche mit beachtet werden}
  (eof(f));
  IF eof(f) AND (test(x2,xt)<>ant[1]) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x3[i]:=xt[i];
  gotoXY(4,8); write('V3: '); WriteColor(z2);
  drei:
  gotoXY(4,9); write('E3: ');
  readln(ant[2]);
  IF ant[2]=richtig THEN
  BEGIN
    ShowText(3);      {Der Algo wiederholt sich eigentlich, man kann aber}
    winsound;
    exit;             {keine Schleife nehmen, da sich die Bedingungen immer}
  END;                {�ndern.}
  IF (Digits=2) AND (zi=9) AND (ant[0]='') AND (ant[1]='') AND (ant[2]='') THEN
  BEGIN
    x4[0]:=7;
    x4[1]:=8;
    gotoXY(4,10); write('V4: '); WriteColor(78);
    GOTO vier;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2])) OR
  (eof(f));
  IF (eof(f) AND (test(x3,xt)<>ant[2])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x4[i]:=xt[i];
  gotoXY(4,10); write('V4: '); WriteColor(z2);
  vier:
  gotoXY(4,11); write('E4: ');
  readln(ant[3]);
  IF ant[3]=richtig THEN
  BEGIN
    ShowText(3);
    winsound;
    exit;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x4,xt)<>ant[3])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  gotoXY(4,12); write('V5: '); WriteColor(z2);
  gotoXY(4,13); write('E5: ');
  readln(ant[4]);
  IF ant[4]=richtig THEN
  BEGIN
    ShowText(3);
    winsound;
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x5[i]:=xt[i];
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x5,xt)<>ant[4])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  gotoXY(4,14); write('V6: '); WriteColor(z2);
  gotoXY(4,15); write('E6: ');
  readln(ant[5]);
  IF ant[5]=richtig THEN
  BEGIN
    ShowText(3);
    winsound;
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x6[i]:=xt[i];
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x6,xt)<>ant[5])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  gotoXY(4,16); write('V7: '); WriteColor(z2);
  gotoXY(4,17); write('E7: ');
  readln(ant[6]);
  IF ant[6]=richtig THEN
  BEGIN
    ShowText(3);
    winsound;
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x7[i]:=xt[i];
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]) AND
  (test(x7,xt)=ant[6]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x7,xt)<>ant[6])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  gotoXY(4,18); write('V8: '); WriteColor(z2);
  gotoXY(4,19); write('E8: ');
  readln(ant[7]);
  IF ant[7]=richtig THEN
  BEGIN
    ShowText(3);
    winsound;
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x8[i]:=xt[i];
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]) AND
  (test(x7,xt)=ant[6]) AND
  (test(x8,xt)=ant[7]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x8,xt)<>ant[7])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  gotoXY(4,20); write('V9: '); WriteColor(z2);
  gotoXY(4,21); write('E9: ');
  readln(ant[8]);
  IF ant[8]=richtig THEN
  BEGIN
    ShowText(3);
    winsound;
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x9[i]:=xt[i];
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]) AND
  (test(x7,xt)=ant[6]) AND
  (test(x8,xt)=ant[7]) AND
  (test(x9,xt)=ant[8]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x9,xt)<>ant[8])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  gotoXY(4,22); write('V10:'); WriteColor(z2);
  gotoXY(4,23); write('E10:');
  readln(ant[9]);
  IF ant[9]=richtig THEN
  BEGIN
    ShowText(3);
    winsound;
    exit;
  END ELSE
  BEGIN
    ShowText(5);
    losesound;
    exit;
  END;
END;

PROCEDURE CC;
TYPE antwort=ARRAY [0..10] OF STRING;
VAR  x,x1,x2,x3,x4,x5,x6,x7,
     x8,x9,x10,xg:combi;
     ant:antwort;
     i:INTEGER;
     number:LONGINT;
     ch:CHAR;
label zwei,drei,vier;
BEGIN
  DrawGameScreen(false);        {Zeichnet Spielbildschirm}
  init(false);                  {Initialisiert zi,Digits}
  randomize;
  gotoXY(28,5);
  write('(1) Kombination');
  gotoXY(28,6);
  write('    selber w�hlen');
  gotoXY(28,7);
  write('(2) Zufalls-');
  gotoXY(28,8);
  write('    kombination');
  REPEAT
  ch:=readkey;
  UNTIL (ch='1') OR (ch='2');
  IF ch='1' THEN
  BEGIN
    number:=Choiceboard(Digits,zi,49,4);
    split(1,number);
    FOR i:=0 TO Digits-1 DO xg[i]:=xt[i];
  END;
  IF ch='2' THEN
  BEGIN
    gotoXY(50,5);
    write('Geheimkombination');
    gotoXY(50,7);
    FOR i:=0 TO Digits-1 DO
    BEGIN
      xg[i]:=random(zi)+1;
      writeColor(xg[i]);
    END;
  END;
  HideText;
  erzeuge(Digits,zi);           {Listendatei erzeugen}
  FOR i:=0 TO Digits-1 DO x1[i]:=(i MOD zi)+1;      {1. Versuch, z.B. 1234}
  reset(f);    {Listendatei �ffnen}
  TextColor(White);
  gotoXY(4,4); write('V1: ');
  FOR i:=0 TO Digits-1 DO WriteColor(x1[i]);
  gotoXY(4,5);
  write('E1: ');
  ant[0]:=test(xg,x1);
  write(ant[0]);
  IF ant[0]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  IF (zi>=3) AND (Digits=3) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    gotoXY(4,6); write('V2: '); WriteColor(122);
    GOTO zwei;
  END;
  IF (zi>=4) AND (Digits=4) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=2;
    gotoXY(4,6); write('V2: '); WriteColor(1222);
    GOTO zwei;
  END;
  IF (zi>=5) AND (Digits=5) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(12233);
    GOTO zwei;
  END;
  IF (zi>=6) AND (Digits=6) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(122333);
    GOTO zwei;
  END;
  IF (zi>=7) AND (Digits=7) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    x2[6]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(1223333);
    GOTO zwei;
  END;
  IF (zi>=8) AND (Digits=8) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    x2[6]:=3;
    x2[7]:=3;
    gotoXY(4,6); write('V2: '); WriteColor(12233333);
    GOTO zwei;
  END;
  IF (zi=9) AND (Digits=9) AND (ant[0]='+') THEN     {Verbesserung des Algo}
  BEGIN
    x2[0]:=1;
    x2[1]:=2;
    x2[2]:=2;
    x2[3]:=3;
    x2[4]:=3;
    x2[5]:=3;
    x2[6]:=4;
    x2[7]:=4;
    x2[8]:=4;
    gotoXY(4,6); write('V2: '); WriteColor(122333444);
    GOTO zwei;
  END;
  IF (ant[0]='') AND (zi>Digits+1) THEN    {Verbesserung des Algo}
  BEGIN
    FOR i:=0 TO Digits-1 DO x2[i]:=(i MOD (zi-Digits))+Digits+1;
    gotoXY(4,6); write('V2: ');
    FOR i:=0 TO Digits-1 DO WriteColor(x2[i]);
    GOTO zwei;
  END;
  REPEAT
    read(f,z2);     {Zahl aus Listendatei lesen}
    split(1,z2);   {Zahl in einzelne Ziffern zerlegen}
  UNTIL (test(x1,xt)=ant[0]) OR (eof(f));
  IF (eof(f) AND (test(x1,xt)<>ant[0])) OR (z2=0) THEN     {2.Bedingung notwendig,da z.B. 4444 bei 4 Ziffern}
  BEGIN                                      {noch richtig sein kann, 3. Bedingung, weil er manchmal Null anbietet}
    Showtext(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x2[i]:=xt[i];  {gefunden Testzahl wird im neuen Array gespeichert,}
  gotoXY(4,6); write('V2: '); WriteColor(z2);            {da sie bei der n�chsten Suche �berschrieben wird}
  zwei:
  gotoXY(4,7); write('E2: ');
  ant[1]:=test(xg,x2);
  write(ant[1]);
  IF ant[1]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  IF (zi>=4) AND (Digits=4) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=3;
    x3[1]:=4;
    x3[2]:=4;
    x3[3]:=4;
    gotoXY(4,8); write('V3: '); WriteColor(3444);
    GOTO drei;
  END;
  IF (zi>=5) AND (Digits=5) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=4;
    x3[2]:=5;
    x3[3]:=5;
    x3[4]:=5;
    gotoXY(4,8); write('V3: '); WriteColor(44555);
    GOTO drei;
  END;
  IF (zi>=6) AND (Digits=6) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=5;
    x3[2]:=5;
    x3[3]:=6;
    x3[4]:=6;
    x3[5]:=6;
    gotoXY(4,8); write('V3: '); WriteColor(455666);
    GOTO drei;
  END;
  IF (zi>=7) AND (Digits=7) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=5;
    x3[2]:=5;
    x3[3]:=6;
    x3[4]:=6;
    x3[5]:=6;
    x3[6]:=6;
    gotoXY(4,8); write('V3: '); WriteColor(4556666);
    GOTO drei;
  END;
  IF (zi>=8) AND (Digits=8) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=4;
    x3[1]:=5;
    x3[2]:=5;
    x3[3]:=6;
    x3[4]:=6;
    x3[5]:=6;
    x3[6]:=6;
    x3[7]:=6;
    gotoXY(4,8); write('V3: '); WriteColor(45566666);
    GOTO drei;
  END;
  IF (zi=9) AND (Digits=9) AND (ant[0]='+') AND (ant[1]='') THEN {Verbesserung des Algo}
  BEGIN
    x3[0]:=5;
    x3[1]:=6;
    x3[2]:=6;
    x3[3]:=7;
    x3[4]:=7;
    x3[5]:=7;
    x3[6]:=8;
    x3[7]:=8;
    x3[8]:=8;
    gotoXY(4,8); write('V3: '); WriteColor(566777888);
    GOTO drei;
  END;
  IF (ant[0]='') AND (ant[1]='') AND (zi>((2*Digits)+1)) THEN    {Verbesserung des Algo}
  BEGIN
    FOR i:=0 TO Digits-1 DO x3[i]:=(i MOD (zi-2*Digits))+2*Digits+1;
    gotoXY(4,8); write('V3: ');
    FOR i:=0 TO Digits-1 DO WriteColor(x3[i]);
    GOTO drei;
  END;
  REPEAT
    read(f,z2);    {an der letzten Stelle wird weitergelesen, nicht wieder von vorn}
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND    {alle vorhergehenden Versuch m�ssen}
  (test(x2,xt)=ant[1])) OR           {bei der Suche mit beachtet werden}
  (eof(f));
  IF eof(f) AND (test(x2,xt)<>ant[1]) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x3[i]:=xt[i];
  gotoXY(4,8); write('V3: '); WriteColor(z2);
  drei:
  gotoXY(4,9); write('E3: ');
  ant[2]:=test(xg,x3);
  write(ant[2]);
  IF ant[2]=richtig THEN
  BEGIN
    ShowText(6);      {Der Algo wiederholt sich eigentlich, man kann aber}
    winsound;
    exit;             {keine Schleife nehmen, da sich die Bedingungen immer}
  END;                {�ndern.}
  IF (Digits=2) AND (zi=9) AND (ant[0]='') AND (ant[1]='') AND (ant[2]='') THEN
  BEGIN
    x4[0]:=7;
    x4[1]:=8;
    gotoXY(4,10); write('V4: '); WriteColor(78);
    GOTO vier;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2])) OR
  (eof(f));
  IF (eof(f) AND (test(x3,xt)<>ant[2])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x4[i]:=xt[i];
  gotoXY(4,10); write('V4: '); WriteColor(z2);
  vier:
  gotoXY(4,11); write('E4: ');
  ant[3]:=test(xg,x4);
  write(ant[3]);
  IF ant[3]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x4,xt)<>ant[3])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x5[i]:=xt[i];
  gotoXY(4,12); write('V5: '); WriteColor(z2);
  gotoXY(4,13); write('E5: ');
  ant[4]:=test(xg,x5);
  write(ant[4]);
  IF ant[4]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x5,xt)<>ant[4])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x6[i]:=xt[i];
  gotoXY(4,14); write('V6: '); WriteColor(z2);
  gotoXY(4,15); write('E6: ');
  ant[5]:=test(xg,x6);
  write(ant[5]);
  IF ant[5]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x6,xt)<>ant[5])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x7[i]:=xt[i];
  gotoXY(4,16); write('V7: '); WriteColor(z2);
  gotoXY(4,17); write('E7: ');
  ant[6]:=test(xg,x7);
  write(ant[6]);
  IF ant[6]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]) AND
  (test(x7,xt)=ant[6]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x7,xt)<>ant[6])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x8[i]:=xt[i];
  gotoXY(4,18); write('V8: '); WriteColor(z2);
  gotoXY(4,19); write('E8: ');
  ant[7]:=test(xg,x8);
  write(ant[7]);
  IF ant[7]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]) AND
  (test(x7,xt)=ant[6]) AND
  (test(x8,xt)=ant[7]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x8,xt)<>ant[7])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x9[i]:=xt[i];
  gotoXY(4,20); write('V9: '); WriteColor(z2);
  gotoXY(4,21); write('E9: ');
  ant[8]:=test(xg,x9);
  write(ant[8]);
  IF ant[8]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END;
  REPEAT
    read(f,z2);
    split(1,z2);
  UNTIL ((test(x1,xt)=ant[0]) AND
  (test(x2,xt)=ant[1]) AND
  (test(x3,xt)=ant[2]) AND
  (test(x4,xt)=ant[3]) AND
  (test(x5,xt)=ant[4]) AND
  (test(x6,xt)=ant[5]) AND
  (test(x7,xt)=ant[6]) AND
  (test(x8,xt)=ant[7]) AND
  (test(x9,xt)=ant[8]))
  OR
  (eof(f));
  IF (eof(f) AND (test(x9,xt)<>ant[8])) OR (z2=0) THEN
  BEGIN
    ShowText(4);
    exit;
  END;
  FOR i:=0 TO Digits-1 DO x10[i]:=xt[i];
  gotoXY(4,22); write('V10:'); WriteColor(z2);
  gotoXY(4,23); write('E10:');
  ant[9]:=test(xg,x10);
  write(ant[9]);
  IF ant[9]=richtig THEN
  BEGIN
    ShowText(6);
    winsound;
    exit;
  END ELSE
  BEGIN
    ShowText(5);
    losesound;
    exit;
  END;
END;

PROCEDURE regeln;
BEGIN
  clrscr;
  DrawFrame(20,1,59,3,false);   {Mastermind-Umrandung}
  DrawFrame(2,2,79,24,false);   {Hauptumrandung}
  gotoXY(20,2); write('�');
  gotoXY(59,2); write('�');
  TextColor(LightBlue);
  gotoXY(21,2); write(' * * *  MASTERMIND-SPIELREGELN  * * * ');
  TextColor(White);
  gotoxy(4,5);
  write('Bei dem Spiel Mastermind (deutsche Variante: Superhirn), versucht');
  gotoxy(4,6);
  write('Spieler A eine geheime Kombination aus verschiedenen Farben zu erraten.');
  gotoxy(4,7);
  write('Dabei probiert er bestimmte Kombinationen aus, die Spieler B, der die');
  gotoxy(4,8);
  write('Geheimkombination kennt, bewerten muss.');
  gotoxy(4,9);
  write('Spieler B muss Auskunft geben, ob richtige Farben vorhanden sind und ob');
  gotoxy(4,10);
  write('sie an der richtigen Stelle stehen.');
  gotoxy(4,11);
  write('Durch �berlegungen aus diesen Hinweisen kann Spieler A dann auf die');
  gotoxy(4,12);
  write('richtige Kombination schlie�en. Je mehr verschiedene Farben und Stellen');
  gotoxy(4,13);
  write('verwendet werden, desto schwerer ist es die Kombination zu erraten.');
  gotoxy(27,23);
  write('Zur�ck zum Men� mit Taste');
  readkey;
END;

PROCEDURE anleitung;
VAR i : INTEGER;
BEGIN
  clrscr;
  DrawFrame(20,1,59,3,false);   {Mastermind-Umrandung}
  DrawFrame(2,2,79,24,false);   {Hauptumrandung}
  gotoXY(20,2); write('�');
  gotoXY(59,2); write('�');
  TextColor(LightBlue);
  gotoXY(21,2); write(' * * * * MASTERMIND-ANLEITUNG * * * * ');
  TextColor(White);
  gotoxy(4,5);
  write('Zu Beginn kann man w�hlen auf welcher Seite man spielen m�chte.');
  gotoxy(4,6);
  write('Danach muss festgelegt werden mit wie vielen Stellen und mit wie');
  gotoxy(4,7);
  write('vielen verschiedenen Farben gespielt werden soll.');
  gotoxy(4,8);
  write('Das System ist leicht zu handhaben: Mit den Pfeiltasten wird die Auswahl');
  gotoxy(4,9);
  write('unten verschoben. Jede Farbe muss mit Enter best�tigt werden, bevor die');
  gotoxy(4,10);
  write('Auswahl zur n�chsten Stelle springt.');
  gotoxy(4,11);
  write('Raten sie selber, erhalten sie die Antwort auf ihren Versuch in der linken');
  gotoxy(4,12);
  write('Spalte. Ein Plus steht f�r eine richtige Farbe an der richtigen Stelle.');
  gotoxy(4,13);
  write('Minus steht f�r eine richtige Farbe, die an der falschen Stelle steht.');
  gotoxy(4,14);
  write('Wenn der Computer r�t, m�ssen Sie zu Beginn ihre Geheimkombination');
  gotoxy(4,15);
  write('eingeben. Im Anschluss daran r�t der Computer. Ihre Aufgabe dabei ist es');
  gotoxy(4,16);
  write('die Versuche ebenfalls mit Plus und Minus zu bewerten.');
  TextColor(140);
  drawframe(3,17,78,19,false);
  gotoxy(4,18);
  TextColor(12);
  write('Wichtig dabei ist es, dass immer zuerst alle Pluszeichen gesetzt werden!');
  TextColor(White);
  gotoxy(4,20);
  write('Geben sie auch dann die richtige Antwort ein, wenn der Computer Ihre');
  gotoxy(4,21);
  write('Kombination erraten hat, also nur Pluszeichen.');
  gotoxy(27,23);
  write('Zur�ck zum Men� mit Taste');
  readkey;
END;

PROCEDURE crypt;
VAR ch:CHAR;
    code:ARRAY [0..4] OF CHAR;
     v:ARRAY [0..4] OF INTEGER;
     f,f2:TEXT;
     i:LONGINT;
BEGIN
  IF fileexists('highsc.001')=FALSE THEN exit;
  code[0]:='k';
  code[1]:='o';
  code[2]:='m';
  code[3]:='b';
  code[4]:='i';
  FOR i:=0 TO 4 DO v[i]:=ORD(code[i])-97;
  assign(f,'highsc.001');
  reset(f);
  assign(f2,'crypt');
  rewrite(f2);
  i:=0;
  REPEAT
    read(f,ch);
    write(f2,CHR(ORD(ch)+v[i MOD 5]));
    INC(i);
  UNTIL eof(f);
  close(f);
  close(f2);
  erase(f);
END;

PROCEDURE decrypt;
VAR ch:CHAR;
    code:ARRAY [0..4] OF CHAR;
     v:ARRAY [0..4] OF INTEGER;
     f,f2:TEXT;
     i:LONGINT;
BEGIN
  IF Fileexists('crypt')=FALSE THEN exit;
  code[0]:='k';
  code[1]:='o';
  code[2]:='m';
  code[3]:='b';
  code[4]:='i';
  FOR i:=0 TO 4 DO v[i]:=ORD(code[i])-97;
  assign(f,'crypt');
  reset(f);
  assign(f2,'highsc.001');
  rewrite(f2);
  i:=0;
  REPEAT
    read(f,ch);
    write(f2,CHR(ORD(ch)-v[i MOD 5]));
    INC(i);
  UNTIL eof(f);
  close(f);
  close(f2);
  erase(f);
END;

PROCEDURE Credits;
VAR x,y,c:INTEGER;
BEGIN
  clrscr;
  randomize;
  gotoxy(15,8);
  write('Programmiert mit Borland Turbo Pascal 7.0 von:');
  gotoxy(15,15);
  write('Algorithmus');
  gotoxy(40,15);
  write(' - Benjamin Sambale');
  gotoxy(15,17);
  write('Grafische');
  gotoxy(15,18);
  write('Benutzeroberfl�che');
  gotoxy(40,17);
  write(' - Tilmann Schilling');
  REPEAT
    x:=random(79)+1;
    y:=random(25)+1;
    c:=random(16)+1;
    IF (x<12) OR (x>62) OR (y<7) OR (y>19) THEN
    BEGIN
      GOTOXY(x,y);
      textcolor(c);
      write('*');
    END;
  UNTIL keypressed;
  readkey;
  textcolor(White);
END;

BEGIN
  cheats:=FALSE;
  decrypt;
  TextBackground(0);
  TextColor(15);
  Quit:=FALSE;
  REPEAT
    i:=MenuScreen;
    CASE i OF
    1: DuRaetst;
    2: BEGIN CRaet; readkey; END;
    3: BEGIN CC; readkey; END;
    4: regeln;
    5: anleitung;
    6: ShowHighscore;
    7: Credits;
    8: Quit:=TRUE;
    END;
  UNTIL (Quit=True);
  crypt;
  IF FileExists('liste.txt') THEN
  BEGIN
    assign(f,'liste.txt');
    erase(f);
  END;
END.